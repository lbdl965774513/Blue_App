package com.blue.bean;

public class NotePhoto {
	
	public String img;
}
