package com.blue.bean;

import com.google.gson.annotations.SerializedName;

public class Version {
	/**
	 * �汾��
	 */
	@SerializedName("version")
	public String VersionString;
    /**
     * ����apk���صĵ�ַ
     */
	@SerializedName("url")
	public String ApkUrlString;
}
