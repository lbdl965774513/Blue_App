package com.blue.ui.fragment;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import com.actionbarsherlock.app.SherlockFragment;
import com.blue.R;
import com.blue.adapter.NewsListAdapter;
import com.blue.app.BlueApplication;
import com.blue.bean.Note;
import com.blue.conninternet.ListDataRequest;
import com.blue.global.NewsOnItemClickListener;
import com.blue.lib.ptr.PullToRefreshBase;
import com.blue.lib.ptr.PullToRefreshBase.OnLastItemVisibleListener;
import com.blue.lib.ptr.PullToRefreshBase.OnRefreshListener;
import com.blue.lib.ptr.PullToRefreshListView;
import com.blue.lib.volley.Request.Method;
import com.blue.lib.volley.RequestQueue;
import com.blue.lib.volley.Response.Listener;
import com.blue.lib.volley.toolbox.JsonObjectRequest;
import com.blue.lib.volley.toolbox.Volley;
import com.blue.ui.user.UserCenterActivity;
import com.blue.util.HttpUtils;
import com.blue.util.LoginUtils;
import com.blue.util.SubmitPara;
import com.nostra13.universalimageloader.core.ImageLoader;

/**
 * @author SLJM
 * @create 2014-3-21
 * @version 1.0
 * @desc ��ҳ ��ҵ��Ѷ
 */

public class HomeFragment extends SherlockFragment implements OnClickListener,OnLastItemVisibleListener, OnRefreshListener<ListView>,OnGestureListener{

	// ��ҳ��ؼ�
	private ListView lv;
	private PullToRefreshListView home_main_lv;
	private ImageButton user_center_ib,post_ib;
	private TextView title_tv;
	// ͷ���ؼ�
	private View headerView;
	private ViewFlipper img_header_vf;
	private LinearLayout point_header_ll;
	// ͷ��point����
	private ArrayList<ImageView> point_header_array;
	// ͷ��ImageView�ļ���
	private ArrayList<ImageView> img_header_array;
	/** ���ӱ�ʶ(�ڼ�������)*/
	private int page_number = 0;
	private int pageIndex = 0;
	//ÿҳ��������
	private static final int page_length = 10;
	private Context context;
	private NewsListAdapter homeAdapter;
	private LayoutInflater layoutInflater;
	private ImageLoader imageLoader;
	private Thread thread;
	private RequestQueue requestQueue;
	private final static String TAG = "HomeFragment";

	public HomeFragment(){
		super();
	}
	
	public static HomeFragment getInstance(){
		HomeFragment homeFragment = new HomeFragment();
		
		return homeFragment;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
		
		View showLayout = inflater.inflate(R.layout.home, container, false);
		requestQueue = Volley.newRequestQueue(getActivity());
		
		initView(showLayout, inflater);
		getArticleList(page_number);
		
		requestQueue.start();

		return showLayout;

	}

	/** ��ʼ����ҳ�沼��Ԫ�� */
	private void initView(View contentView, LayoutInflater inflater) {
		
		context = getActivity();
//		gestureDetector = new GestureDetector(context, listener)
		imageLoader = ImageLoader.getInstance();
		home_main_lv = (PullToRefreshListView) contentView.findViewById(R.id.home_main_lv);
		//actionbar 
		post_ib = (ImageButton)contentView.findViewById(R.id.post_actionbar_ib);
		user_center_ib = (ImageButton)contentView.findViewById(R.id.user_actionbar_ib);
		title_tv = (TextView)contentView.findViewById(R.id.title_center_actionbar_main_tv);
		
		title_tv.setText("��ҳ");
		post_ib.setVisibility(View.GONE);
		
		home_main_lv.setOnRefreshListener(this);
		home_main_lv.setOnLastItemVisibleListener(this);
		lv = home_main_lv.getRefreshableView();
		lv.setOnItemClickListener(new NewsOnItemClickListener(getActivity(),0));
//		home_main_lv.setOnItemClickListener(this);
		user_center_ib.setOnClickListener(this);
		
		initHeaderView();

	}

	/** ��ʼ��ͷ��ͼƬ */
	private void initHeaderView() {
		layoutInflater = LayoutInflater.from(getActivity());
//		layoutInflater = (LayoutInflater) getActivity().getSystemService(getActivity().LAYOUT_INFLATER_SERVICE);
		headerView = layoutInflater.inflate(R.layout.main_header_image, lv,false);
		img_header_vf = (ViewFlipper) headerView.findViewById(R.id.img_main_header_vf);
		point_header_ll = (LinearLayout) headerView.findViewById(R.id.point_main_header_ll);

		getHeaderImg();

	}
	/**��ȡ������ͼƬ*/
	private void getHeaderImg() {
		JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Method.POST, HttpUtils.initArticleURL("Banner_list"),
				null, new Listener<JSONObject>() {

					@Override
					public void onResponse(JSONObject response) {
						Log.i(TAG, "header image"+response);
						if (response.optString("code").equals("1")) {
							
							try {
								initHeaderImageView(response.getJSONArray("content"));
							} catch (JSONException e) {
								e.printStackTrace();
							}
						}
					}
				}, null);
		requestQueue.add(jsonObjectRequest);
		requestQueue.start();
	}
	/** ��ʼ��ͷ��������ͼƬ 
	 * @throws JSONException */
	private void initHeaderImageView(JSONArray jsonArray) throws JSONException {
		JSONArray image_array = jsonArray;
		img_header_array = new ArrayList<ImageView>();

		ImageView img_header;
//		LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
		
		for (int i = 0; i < image_array.length(); i++) {
			img_header = new ImageView(getActivity());

			img_header.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, 300));
			img_header.setScaleType(ImageView.ScaleType.CENTER_CROP);
			imageLoader.displayImage(image_array.optString(i), img_header);
			img_header_vf.addView(img_header);
			img_header_array.add(img_header);
		}

		initHeaderPoint();

		draw_Point(0);// Ĭ���״ν���
		lv.addHeaderView(headerView);// Ҫд��setAdapterǰ��
//		autoChangeImg();
		
		thread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					autoChangeImg();
					draw_Point(pageIndex);
					thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		thread.start();
	}

	/** ��ʼ��ͷ��point */
	private void initHeaderPoint() {
		point_header_array = new ArrayList<ImageView>();
		// ����point��ImageView
		ImageView point_img_header;

		for (int i = 0; i < img_header_array.size(); i++) {
			point_img_header = new ImageView(getActivity());
			LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
					new ViewGroup.LayoutParams(LayoutParams.WRAP_CONTENT,
							LayoutParams.WRAP_CONTENT));
			layoutParams.leftMargin = 30;

			point_header_ll.addView(point_img_header, layoutParams);

			point_header_array.add(point_img_header);
		}
	}

	/** ����ѡ�е� */
	private void draw_Point(int index) {
		for (int i = 0; i < point_header_array.size(); i++) {
			point_header_array.get(i).setImageResource(
					R.drawable.main_header_unfocused);
		}
		point_header_array.get(index).setImageResource(
				R.drawable.main_header_focused);
	}
	
	/** ��ȡ��ҵ��Ѷ�б���Ϣ */
	private void getArticleList(int number) {
		 
		 ListDataRequest listDataRequest = new ListDataRequest(Method.POST, HttpUtils.initArticleURL("article_list"), 
				 SubmitPara.getNoteList(4, number), new Listener<ArrayList<Note>>() {

					@Override
					public void onResponse(ArrayList<Note> response) {
						Log.i(TAG, "news list  = " + response);
						if (response != null && !response.isEmpty()) {
							initAdapter(response);
						}
					}
				}, null); 
		 requestQueue.add(listDataRequest);
		
	}
	/**��ʼ��������*/
	private void initAdapter(ArrayList<Note> note_array) {
		
		if(homeAdapter == null){
			homeAdapter = new NewsListAdapter(getActivity(),note_array);
			home_main_lv.setAdapter(homeAdapter);
		}else{
			if (page_number == 0) {
				homeAdapter.addFirstPageData(note_array);
			} else {
				homeAdapter.addOtherPageData(note_array);
			}
		}
		
		home_main_lv.onRefreshComplete();
	}

	/***
	 * ���ص�ǰ�ڼ���
	 */
	private int getPageIndex(View view) {
		for (int i = 0; i < img_header_array.size(); i++) {
			if (view == img_header_array.get(i))
				return i;
		}
		return 0;

	}

	/** ͼƬ�Զ��л� */
	private void autoChangeImg() {
		pageIndex = getPageIndex(img_header_vf.getCurrentView());
		
		if (pageIndex == img_header_vf.getChildCount() - 1){
			pageIndex = 0;
		}			
		else{
			pageIndex++;
		}
		img_header_vf.showNext();
		
	}
	

	@Override
	public void onClick(View v) {
		
		Intent intent = new Intent(context, UserCenterActivity.class);
		
		switch (v.getId()) {
		case R.id.user_actionbar_ib:
			if(BlueApplication.isLogin(context)){
				intent.putExtra("user_id", LoginUtils.getLoginUserid(context));
				startActivity(intent);
			}
			break;
		}
	}

	@Override
	public void onLastItemVisible() {
		Log.i(TAG, "last item visible");
		page_number = page_number + page_length;
		getArticleList(page_number);
		requestQueue.start();
	}


	@Override
	public void onRefresh(PullToRefreshBase<ListView> refreshView) {
		page_number = 0;
		getArticleList(page_number);
		requestQueue.start();
	}

	@Override
	public void onStop() {
		super.onStop();
		requestQueue.stop();
	}
	@Override
	public void onDestroy() {
		super.onDestroy();
//		thread.stop();
	}

	@Override
	public boolean onDown(MotionEvent arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float arg2,
			float arg3) {
		
		if (e1.getX() > e2.getX()) {
			img_header_vf.showNext();
		}else if(e1.getX() < e2.getX()){
			img_header_vf.setInAnimation(context,R.anim.push_right_in);
			img_header_vf.setOutAnimation(context,R.anim.push_right_out);
			img_header_vf.showPrevious();
			img_header_vf.setInAnimation(context, R.anim.push_left_in);
			img_header_vf.setOutAnimation(context,R.anim.push_left_out);
		}else {
			return false;
		}
		return true;
	}

	@Override
	public void onLongPress(MotionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onScroll(MotionEvent arg0, MotionEvent arg1, float arg2,
			float arg3) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onShowPress(MotionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onSingleTapUp(MotionEvent arg0) {
		// TODO Auto-generated method stub
		return false;
	}




}