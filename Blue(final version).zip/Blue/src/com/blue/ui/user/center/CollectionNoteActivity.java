package com.blue.ui.user.center;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.blue.R;
import com.blue.adapter.KaXiuListAdapter;
import com.blue.bean.Note;
import com.blue.conninternet.ListDataRequest;
import com.blue.lib.ptr.PullToRefreshBase;
import com.blue.lib.ptr.PullToRefreshBase.OnLastItemVisibleListener;
import com.blue.lib.ptr.PullToRefreshBase.OnRefreshListener;
import com.blue.lib.ptr.PullToRefreshListView;
import com.blue.lib.volley.Request.Method;
import com.blue.lib.volley.RequestQueue;
import com.blue.lib.volley.Response.Listener;
import com.blue.lib.volley.toolbox.JsonObjectRequest;
import com.blue.lib.volley.toolbox.Volley;
import com.blue.util.HttpUtils;
import com.blue.util.LoginUtils;
import com.blue.util.SubmitPara;

/**
 * @author SLJM
 * @create 2014-4-16
 * @desc �ҵ��ղ�
 *
 */
public class CollectionNoteActivity extends Activity implements OnLastItemVisibleListener, OnRefreshListener<ListView> {
	
	private TextView empty_tv;
	private PullToRefreshListView pullToRefreshListView;
	
	private RequestQueue requestQueue;
	private KaXiuListAdapter adapter;
	/** ���ӱ�ʶ(�ڼ�������)*/
	private int page_number = 0;
	private static final String TAG = "CollectionNoteActivity";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.collection);
		
		initView();
		getCollectionList(page_number);
	}
	
	private void initView() {
		requestQueue = Volley.newRequestQueue(this);
		
		empty_tv = (TextView) findViewById(R.id.empty_collection_tv);
		pullToRefreshListView = (PullToRefreshListView)findViewById(R.id.collection_lv);
		
		pullToRefreshListView.setOnRefreshListener(this);
		pullToRefreshListView.setOnLastItemVisibleListener(this);
		
	}

	/**���������ȡ�ղ�����*/
	private void getCollectionList(int number) {
		
		String user_id = LoginUtils.getLoginUserid(this);
		if (TextUtils.isEmpty(user_id)) {
			return;
		}
		Log.i(TAG, "user_id = " + user_id);
		ListDataRequest dataRequest = new ListDataRequest(Method.POST, HttpUtils.initArticleURL("collect_list"), 
				SubmitPara.getNoteList(1, number, user_id), new Listener<ArrayList<Note>>() {
					@Override
					public void onResponse(ArrayList<Note> response) {
						Log.i(TAG, "collection list = " + response);
							initAdapter(response);
						pullToRefreshListView.onRefreshComplete();
					}
				}, null);
		
		requestQueue.add(dataRequest);
		requestQueue.start();
	}
	
	/**��ʼ��������*/
	private void initAdapter(ArrayList<Note> note_array) {
		
		if (note_array.isEmpty()) {
			empty_tv.setVisibility(View.VISIBLE);
			pullToRefreshListView.setEmptyView(empty_tv);
			return;
		}
		
		if(adapter == null){
			adapter = new KaXiuListAdapter(this,note_array,1);
			pullToRefreshListView.setAdapter(adapter);
		}else{
			if (page_number == 0) {
				adapter.addFirstPageData(note_array);
			} else {
				adapter.addOtherPageData(note_array);
			}
		}
	}
	
	/**ɾ���ҵ��ղ��б��������*/
	public void deleteCollect(){
		
	}

	@Override
	protected void onStop() {
		super.onStop();
		requestQueue.stop();
	}

	@Override
	public void onRefresh(PullToRefreshBase<ListView> refreshView) {
		page_number = 0;
		getCollectionList(page_number);
	}

	@Override
	public void onLastItemVisible() {
		page_number = page_number + 10;
		getCollectionList(page_number);
	}

}
