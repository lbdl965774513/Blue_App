package com.blue.ui.user.about;

import com.blue.R;
import com.blue.R.layout;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class InformationActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_information);
	}


}
